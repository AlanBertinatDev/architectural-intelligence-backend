package com.architecture.backend_architecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendArchitectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
